#!/bin/bash

echo "This script will fail!"
exit 1